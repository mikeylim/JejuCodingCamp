console.log('안녕! 제주코딩베이스캠프!');
