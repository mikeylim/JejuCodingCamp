(function() {

    var menuBtn = document.querySelector('.global-menu-btn');

    menuBtn.addEventListener('click', function() {
        document.body.classList.toggle('menu-on');
    });

})();


